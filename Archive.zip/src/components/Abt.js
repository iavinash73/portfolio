function Abt()
{
    return(
        <div>
            <div className="mt-[70px]"></div>
            <h1 className="text-4xl font-DM ml-[65px] font-black link link-underline link-underline-black inline">
                About me
            </h1>
            <div className="text-gray-500 mx-[70px] mt-[20px]">
                A student who wants to widen his knowledge in the area of product development with Coding and wants to make useful changes around him. Very strong and comfortable in Data structures and algorithm and experienced in Frontend dev with Next js. Can work good in team and give efficient solutions to solve real-time problems and bugs.
            </div>
        </div>
    )
}
export default Abt;
