function Contact() {
    return (
        <div>
        <div id="contact" className="relative">
            <img src={require("../images/contact.png")} className="rounded-4xl w-9/12 mt-[50px] mx-auto h-[0rem] opacity-0 md:h-[25rem] md:mb-[40px] lg:opacity-100 lg:h-[30rem]"></img>
            <div className="absolute left-[40px] md:top-[50px] md:ml-[30px] lg:mx-[300px] xl:mx-[300px]">
                <h2 className="font-fr text-center font-black text-sky-800 text-[21px] md:text-[25px] lg:text-[30px] xl:text-[35px] text-left">Wanna know more about me ? Let's get in touch <br></br>
                    <a href="https://www.linkedin.com/in/avinash-pr-0b98a8220/" class="absolute md:top-[50px] mt-[20px]inline text-16px ml-[-210px] mt-[40px] md:ml-[-260px] md:mt-[20px] lg:mt-[60px] lg:ml-[-80px] lg:text-lg group xl:mt-[50px] xl:ml-[-80px]">
                        <span class="relative z-10 block px-5 py-3 overflow-hidden font-medium leading-tight text-gray-800 transition-colors duration-300 ease-out border-2 border-gray-900 rounded-lg group-hover:text-white">
                            <span class="absolute inset-0 w-full h-full px-5 py-3 rounded-lg bg-gray-50"></span>
                            <span class="absolute left-0 w-48 h-48 -ml-2 transition-all duration-[600ms] origin-top-right -rotate-90 -translate-x-full translate-y-12 bg-gray-900 group-hover:-rotate-180 ease"></span>
                            <span class="relative">Contact me :)</span>
                        </span>
                        <span class="absolute bottom-0 right-0 w-full h-12 -mb-1 -mr-1 transition-all duration-200 ease-linear bg-gray-900 rounded-lg group-hover:mb-0 group-hover:mr-0" data-rounded="rounded-lg"></span>
                    </a>
                    </h2>
                <div className="group mt-[100px] font-ca text-[16px] md:text-[20px] lg:top-[230px] lg:left-[280px]">
                    <img className="inline h-[30px] mx-[15px] my-[20px]" src={require("../images/phone.png")}></img>
                    Call me
                    <div className="group-hover:text-black group-hover:scale-[1.2] inline text-gray-500 duration-[400ms] mx-[32px]">+91 9080681237</div>
                </div>
                <div className="group mb-[10px] font-ca text-[16px] md:text-[20px] lg:top-[230px] lg:left-[280px]">
                    <img className="inline h-[30px] mx-[15px] my-[20px]" src={require("../images/mail.png")}></img>
                    Mail me
                    <div className="text-gray-500 mx-[20px] duration-[400ms] group-hover:text-black group-hover:scale-[1.2] inline">avinashcube@gmail.com</div>
                </div>
                <div className="md:h-[20px]"></div>
                <a href="https://www.linkedin.com/in/avinash-pr-0b98a8220/" target="_blank"><img src={require("../images/linkedin.png")} className="mb-[20px] mx-[20px] h-[30px] inline duration-[400ms] hover:scale-[1.2]"></img></a>
                <a href="https://github.com/iavinash73" target="_blank"><img src={require("../images/github.png")} className="mb-[20px] h-[30px] inline duration-[400ms] hover:scale-[1.2]"></img></a>
            </div>
        </div>
        <div className="bg-black text-slate-200 font-so text-right py-[10px] pr-[15px] mt-[360px] md:mt-[0]">
            Made with REACT Js and Tailwind CSS by Avinash.
        </div>
        </div>
    )
}
export default Contact;